package com.example.tipcalculator;

// imports relevant packages for app creation
import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.SeekBar;


public class MainActivity extends AppCompatActivity {
    // creates EditText, TextView and SeekBar variables
    EditText baseamount;
    TextView tippercent;
    TextView tipamount;
    TextView totalamount;
    TextView rating;
    SeekBar seekbar;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // assigns variables to corresponding objects
        baseamount = findViewById(R.id.entertipamount);
        tippercent = findViewById(R.id.tippercent);
        tipamount = findViewById(R.id.tip);
        totalamount = findViewById(R.id.totalamount);
        seekbar = findViewById(R.id.seekBar);
        rating = findViewById(R.id.rating);
        seekbar.setProgress(15);


        // creates a listener for when text input is added to base amount
        baseamount.addTextChangedListener(new TextWatcher() {
            @Override
            // method for before text input is inserted
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            // method for whilst text input is being inserted
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            // method for after text input is inserted
            public void afterTextChanged(Editable s) {
                tipcalculator();
            }
        });


        // creates a listener for when seekbar is moved horizontally
        seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            // method for whilst seekbar is being moved horizontally
            public void onProgressChanged(SeekBar seekbar, int s, boolean b)
            {
                // sets the tip percent result and calls two helper functions
                tippercent.setText(" " + s + "%");
                tipcalculator();
                ratingchange(s);
            }

            @Override
            // method for when seekbar is instantly touched
            public void onStartTrackingTouch(SeekBar seekbar) {
            }

            @Override
            // method for when seekbar is no longer touched
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });


    }

        // first helper that deals with calculations, displays, etc
        private void tipcalculator()
        {
            // wraps code in a try statement that examines code for potential errors
            try
            {
                // converts the base input into a string
                String stringbaseamount = baseamount.getText().toString();

                // converts the converted string base input into a double
                double doublebaseamount = Double.parseDouble(stringbaseamount);

                // grabs the current number value of the seekbar
                double modifiedtippercent = seekbar.getProgress();

                // calculates the updated tip amount and total amount
                double modifiedtipamount = (doublebaseamount) * (modifiedtippercent) / 100;
                double modifiedtotalamount = (doublebaseamount) + (modifiedtipamount);

                // ensures that the tip amount and total amount are to 2 decimal places
                String finaltipamount = String.format("%.2f", modifiedtipamount);
                String finaltotalamount = String.format("%.2f", modifiedtotalamount);

                // displays the tip amount and total amount
                tipamount.setText("         " + finaltipamount);
                totalamount.setText("         " + finaltotalamount);
            }



            // wraps code in catch statement that handles incorrect input type errors
            catch (NumberFormatException e)
            {
                // displays an error message when an input is not a number, empty, whitespace, etc
                Toast.makeText(MainActivity.this, "Enter a valid number",
                        Toast.LENGTH_SHORT).show();
            }
            }

        // second helper that evaluates the tip percent, grading the excellency of the tip
        private void ratingchange(int s)
        {
            // if tip percent is less than ten it states tip is poor with red color
            if (s < 10)
            {
                rating.setText("Poor");
                rating.setTextColor(Color.RED);
            }

            // if tip percent is between 10 and 15 (inclusive) it states tip is acceptable with
            // orange color
            if (s >= 10 && s <= 15)
            {
                rating.setText("Acceptable");
                rating.setTextColor(Color.parseColor("#D56300"));

            }

            // if tip percent is greater than 15 and less than or equal to 20 it states tip
            // is good with light green color
            if (s > 15 && s <= 20)
            {
                rating.setText("Good");
                rating.setTextColor(Color.parseColor("#4cff00"));
            }

            // if tip percent is greater than 20 it states tip is amazing with dark green color
            if (s > 20)
            {
                rating.setText("Amazing");
                rating.setTextColor(Color.parseColor("#298b28"));
            }

        }

    }









